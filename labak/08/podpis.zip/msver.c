#include <stdio.h>
#include <openssl/pem.h>
#include <openssl/evp.h>
#include <openssl/bio.h>
#include <openssl/err.h>
#include <openssl/x509.h>
#include <openssl/pkcs7.h>
#include <openssl/cms.h>

#define INFILE		"in.txt"
#define OUTFILE		"out.eml"
#define PRIV_KEY	"privkey.pem"
#define CERT		"ca.crt"

int main(int argc, char *argv[])
{
	BIO *b64;
	BIO *in, *out, *cin, *pin;
	X509 *cert;
	CMS_ContentInfo *cms;
	EVP_PKEY *pkey;
	unsigned int size;
	unsigned char buf[256];

	CRYPTO_malloc_init(); 
	ERR_load_crypto_strings(); 
    OpenSSL_add_all_algorithms(); 
    ERR_load_OBJ_strings();

	cin = BIO_new_file(CERT, "r");
	if (!cin)
		return 1;

	cert = PEM_read_bio_X509(cin, NULL, NULL, NULL);
	if (!cert) {
		ERR_print_errors_fp(stderr);
		return 1;
	}
	BIO_free(cin);

	pin = BIO_new_file(PRIV_KEY, "r");
	if (!pin) {
		ERR_print_errors_fp(stderr);
		return 1;
	}

	pkey = PEM_read_bio_PrivateKey(pin, NULL, NULL, NULL);
	if (!pkey) {
		ERR_print_errors_fp(stderr);
		return 1;
	}
	BIO_free(pin);

	in = BIO_new_file(INFILE, "rt");
	if(!in)
		return 1;

	/* Pre jednoduchost podpisujem vsetko tak, ako to mam v subore */
	cms = CMS_sign(cert, pkey, NULL, in, CMS_TEXT);
	if (!cms) {
		ERR_print_errors_fp(stderr);
		return 1;
	}
	X509_free(cert);

	out = BIO_new_file(OUTFILE, "w");
	if (!out) {
		ERR_print_errors_fp(stderr);
		return 1;
	}

	BIO_reset(in);
	while ((size = BIO_read(in, buf, 256)) > 0)
		BIO_write(out, buf, size);

	BIO_write(out, "\n\n", 2);

	b64 = BIO_new(BIO_f_base64());
	out = BIO_push(b64, out);

	if (!i2d_CMS_bio(out, cms)) {
		ERR_print_errors_fp(stderr);
		return 1;
	}

	BIO_flush(out);

	BIO_free(in);
	BIO_free(out);
	//CMS_free(cms);
	return 0;
}
